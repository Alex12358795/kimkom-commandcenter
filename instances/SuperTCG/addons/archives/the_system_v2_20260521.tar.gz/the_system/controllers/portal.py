import base64
import mimetypes
from datetime import date, datetime, timedelta
import calendar
from odoo import http, _
from odoo.http import request
from odoo.osv import expression
from markupsafe import Markup
import logging

_logger = logging.getLogger(__name__)

from odoo.addons.project.controllers.portal import ProjectCustomerPortal

class KnowledgeProjectPortal(ProjectCustomerPortal):

    def _get_bridge_task_or_404(self, task_id):
        """Fetch a bridge-visible task only if the current user is assigned to it."""
        task = request.env['project.task'].sudo().browse(task_id)
        if not task.exists() or not task.is_bridge_visible:
            return None
        if request.env.user.id not in task.user_ids.ids:
            return None
        return task

    def _get_portal_tasks_domain(self):
        """ Force the portal task domain to only show tasks assigned to the current user that are bridge-visible. """
        return [
            ('user_ids', 'in', [request.env.user.id]),
            ('is_bridge_visible', '=', True)
        ]

    def _prepare_home_portal_values(self, counters):
        values = super()._prepare_home_portal_values(counters)
        if 'task_count' in counters:
            domain = self._get_portal_tasks_domain()
            values['task_count'] = request.env['project.task'].sudo().search_count(domain)
        hour = datetime.now().hour
        if hour < 12:
            values['bridge_greeting'] = 'Good Morning!'
            values['bridge_greeting_icon'] = 'fa-coffee'
        elif hour < 18:
            values['bridge_greeting'] = 'Good Afternoon!'
            values['bridge_greeting_icon'] = 'fa-sun-o'
        else:
            values['bridge_greeting'] = 'Good Evening!'
            values['bridge_greeting_icon'] = 'fa-moon-o'
        return values

    def _prepare_tasks_values(self, page, date_begin, date_end, sortby, search, search_in, groupby, domain=None, url='/my/tasks'):
        """ Override to add user filter to the domain. """
        if domain is None:
            domain = []
        
        # Add our user filter to the domain
        user_domain = [
            ('user_ids', 'in', [request.env.user.id]),
            ('is_bridge_visible', '=', True)
        ]
        domain = expression.AND([domain, user_domain])
        
        return super()._prepare_tasks_values(page, date_begin, date_end, sortby, search, search_in, groupby, domain=domain, url=url)

    def _task_get_searchbar_sortings(self, milestones_allowed=True, project=None, **kwargs):
        """ Add sequence sorting to match knowledge article order. """
        return {
            'date': {'label': _('Newest'), 'order': 'create_date desc, id desc', 'sequence': 1},
            'name': {'label': _('Title'), 'order': 'name, id', 'sequence': 2},
            'deadline': {'label': _('Deadline'), 'order': 'date_deadline asc, id asc', 'sequence': 3},
            'project': {'label': _('Project'), 'order': 'project_id, id', 'sequence': 4},
            'sequence': {'label': _('SOP Order'), 'order': 'sequence, id', 'sequence': 5},
        }

    @http.route(['/my/tasks', '/my/tasks/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_tasks(self, page=1, date_begin=None, date_end=None, sortby=None, filterby=None, search=None, search_in='content', groupby=None, **kw):
        if not sortby:
            sortby = 'sequence'
        return super().portal_my_tasks(
            page=page, 
            date_begin=date_begin, 
            date_end=date_end, 
            sortby=sortby,
            filterby=filterby, 
            search=search, 
            search_in=search_in, 
            groupby=groupby, 
            **kw
        )

    @http.route(['/my/tasks/<int:task_id>/done'], type='http', auth="user", website=True)
    def portal_task_mark_done(self, task_id, **kw):
        task = self._get_bridge_task_or_404(task_id)
        if not task:
            return request.redirect(request.httprequest.referrer or '/my/tasks')
        
        note = kw.get('note', '').strip()
        task_name = task.name or ''
        
        # Validate [INPUT] marker - require text input
        if '[INPUT]' in task_name and not note:
            # Redirect back with error parameter
            ref = request.httprequest.referrer or '/my/tasks'
            separator = '&' if '?' in ref else '?'
            return request.redirect(f"{ref}{separator}error=input_required&task_id={task_id}")
        
        # Validate [IMAGE] marker - require at least one image
        if '[IMAGE]' in task_name:
            attachments = request.env['ir.attachment'].sudo().search([
                ('res_model', '=', 'project.task'),
                ('res_id', '=', task.id),
                ('mimetype', 'like', 'image/%')
            ], limit=1)
            if not attachments:
                # Redirect back with error parameter
                ref = request.httprequest.referrer or '/my/tasks'
                separator = '&' if '?' in ref else '?'
                return request.redirect(f"{ref}{separator}error=image_required&task_id={task_id}")
        
        # Post note to chatter if provided
        if note:
            task.sudo().message_post(
                body=Markup(_("Note: %s")) % note,
                message_type='comment',
                subtype_xmlid='mail.mt_comment',
                author_id=request.env.user.partner_id.id
            )
        
        task.action_portal_mark_done_recursive()
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/todo'], type='http', auth="user", website=True)
    def portal_task_mark_todo(self, task_id, **kw):
        task = self._get_bridge_task_or_404(task_id)
        if task:
            task.action_portal_mark_todo()
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/help'], type='http', auth="user", methods=['GET', 'POST'], website=True, csrf=True)
    def portal_task_need_help(self, task_id, **kw):
        task = self._get_bridge_task_or_404(task_id)
        if task:
            reason = kw.get('reason')
            task.action_portal_need_help(reason=reason)
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/upload'], type='http', auth="user", methods=['POST'], website=True, csrf=True)
    def portal_task_upload_image(self, task_id, **kw):
        task = self._get_bridge_task_or_404(task_id)
        if not task:
            return request.redirect(request.httprequest.referrer or '/my/tasks')
        try:
            file = kw.get('attachment')
            if file:
                filename = file.filename
                mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
                file_content = file.read()
                
                if file_content:
                    attachment = request.env['ir.attachment'].sudo().create({
                        'name': filename,
                        'raw': file_content,
                        'res_model': 'project.task',
                        'res_id': task.id,
                        'mimetype': mimetype,
                    })
                    
                    # Embed image directly into the chatter message
                    msg_body = Markup(_("Image uploaded from portal checklist.<br/><br/><img src='/web/image/%s' style='max-width: 100%%; max-height: 400px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'/>")) % attachment.id
                    
                    task.sudo().message_post(
                        body=msg_body, 
                        attachment_ids=[attachment.id],
                        message_type='comment',
                        subtype_xmlid='mail.mt_comment',
                        author_id=request.env.user.partner_id.id
                    )
                    _logger.info("Successfully uploaded image %s to task %s", filename, task.id)
                    
                    # Auto-complete task if [IMAGE] marker is present
                    if '[IMAGE]' in (task.name or ''):
                        task.action_portal_mark_done_recursive()
                        _logger.info("Auto-completed task %s with [IMAGE] marker", task.id)
                else:
                    _logger.warning("Empty file uploaded to task %s", task.id)
        except Exception as e:
            _logger.error("Error uploading image to task %s: %s", task_id, str(e))
            
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/calendar'], type='http', auth="user", website=True)
    def portal_calendar(self, year=None, month=None, **kw):
        today = date.today()
        try:
            year = int(year) if year else today.year
            month = int(month) if month else today.month
        except (ValueError, TypeError):
            year, month = today.year, today.month

        if month < 1:
            month = 12
            year -= 1
        elif month > 12:
            month = 1
            year += 1

        # Navigation months
        prev_month, prev_year = (12, year - 1) if month == 1 else (month - 1, year)
        next_month, next_year = (1, year + 1) if month == 12 else (month + 1, year)

        # Calendar grid
        cal = calendar.Calendar(firstweekday=calendar.MONDAY)
        month_days = cal.monthdayscalendar(year, month)
        month_name = calendar.month_name[month]

        # Fetch tasks with planned_date_begin for this month
        first_day = date(year, month, 1)
        if month == 12:
            last_day = date(year + 1, 1, 1) - timedelta(days=1)
        else:
            last_day = date(year, month + 1, 1) - timedelta(days=1)

        domain = [
            ('user_ids', 'in', [request.env.user.id]),
            ('is_bridge_visible', '=', True),
            ('planned_date_begin', '>=', first_day),
            ('planned_date_begin', '<=', last_day),
        ]
        tasks = request.env['project.task'].sudo().search(domain)

        # Group by day, deduplicate by project
        projects_by_day = {}
        for task in tasks:
            task_date = task.planned_date_begin.date() if task.planned_date_begin else None
            if task_date and task_date.month == month and task_date.year == year:
                day_projects = projects_by_day.setdefault(task_date.day, {})
                if task.project_id.id not in day_projects:
                    day_projects[task.project_id.id] = task.project_id

        # Build weeks data
        weeks = []
        for week in month_days:
            week_data = []
            for day in week:
                if day == 0:
                    week_data.append({'day': 0, 'projects': [], 'is_today': False})
                else:
                    is_today = (year == today.year and month == today.month and day == today.day)
                    day_projects = list(projects_by_day.get(day, {}).values())
                    week_data.append({
                        'day': day,
                        'projects': day_projects,
                        'is_today': is_today,
                    })
            weeks.append(week_data)

        values = {
            'year': year,
            'month': month,
            'month_name': month_name,
            'prev_year': prev_year,
            'prev_month': prev_month,
            'next_year': next_year,
            'next_month': next_month,
            'weeks': weeks,
            'today': today,
            'page_name': 'calendar',
        }
        return request.render('the_system.portal_calendar_page', values)
