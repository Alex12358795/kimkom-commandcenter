odoo.define('the_system.bridge_help', function () {
    function initBridgeHelp() {
        const helpModal = document.getElementById('modal_bridge_help');
        if (!helpModal) return;

        helpModal.addEventListener('show.bs.modal', function (event) {
            const button = event.relatedTarget;
            if (!button) return;
            const taskId = button.getAttribute('data-task-id');
            const form = document.getElementById('bridge_help_form');
            if (form && taskId) {
                form.action = '/my/tasks/' + taskId + '/help';
            }
        });

        helpModal.addEventListener('shown.bs.modal', function () {
            const textarea = document.getElementById('bridge_help_reason');
            if (textarea) textarea.focus();
        });
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBridgeHelp);
    } else {
        initBridgeHelp();
    }
});
