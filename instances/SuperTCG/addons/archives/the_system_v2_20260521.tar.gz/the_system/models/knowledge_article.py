from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from markupsafe import Markup
import copy
import lxml.html
import calendar
import logging

_logger = logging.getLogger(__name__)

class KnowledgeBridgeSchedule(models.Model):
    _name = 'knowledge.bridge.schedule'
    _description = 'Knowledge Project Bridge Schedule Line'

    article_id = fields.Many2one('knowledge.article', string='Article', required=True, ondelete='cascade')
    employee_id = fields.Many2one('hr.employee', string='Employee', domain="[('user_id', '!=', False)]", required=True)
    
    schedule_type = fields.Selection([
        ('weekly', 'Weekly'),
        ('monthly', 'Monthly'),
        ('quarterly', 'Quarterly'),
        ('yearly', 'Yearly'),
    ], string='Schedule Type', required=True, default='weekly')
    
    # Weekly fields
    mon = fields.Boolean(string='Monday')
    tue = fields.Boolean(string='Tuesday')
    wed = fields.Boolean(string='Wednesday')
    thu = fields.Boolean(string='Thursday')
    fri = fields.Boolean(string='Friday')
    sat = fields.Boolean(string='Saturday')
    sun = fields.Boolean(string='Sunday')
    
    # Periodic: day of month (1-28)
    day = fields.Integer(string='Day of Month', default=1, help="Day of month for monthly/quarterly/yearly schedules (1-28)")
    
    # Computed field for display in list view
    schedule_display = fields.Char(string='Schedule', compute='_compute_schedule_display', store=False)

    @api.depends('schedule_type', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat', 'sun', 'day')
    def _compute_schedule_display(self):
        for rec in self:
            if rec.schedule_type == 'weekly':
                days = []
                if rec.mon: days.append('Mo')
                if rec.tue: days.append('Tu')
                if rec.wed: days.append('We')
                if rec.thu: days.append('Th')
                if rec.fri: days.append('Fr')
                if rec.sat: days.append('Sa')
                if rec.sun: days.append('Su')
                rec.schedule_display = ', '.join(days) if days else 'No days selected'
            elif rec.schedule_type == 'monthly':
                rec.schedule_display = 'Day %s of each month' % (rec.day or 1)
            elif rec.schedule_type == 'quarterly':
                rec.schedule_display = 'Day %s of Jan/Apr/Jul/Oct' % (rec.day or 1)
            elif rec.schedule_type == 'yearly':
                rec.schedule_display = 'Day %s of January' % (rec.day or 1)
            else:
                rec.schedule_display = ''


class KnowledgeArticle(models.Model):
    _inherit = 'knowledge.article'

    is_project_template_bridge = fields.Boolean(string='Is Project Template', default=False)
    is_processed_bridge = fields.Boolean(string='Processed for Project', default=False)
    bridge_project_id = fields.Many2one('project.project', string='Generated Master Project', readonly=True)

    bridge_project_name = fields.Char(string='Project Name')
    
    # The New Matrix
    bridge_schedule_ids = fields.One2many('knowledge.bridge.schedule', 'article_id', string='Schedules')

    def action_reset_bridge(self):
        """ Allow re-running the bridge by resetting the processed status. """
        self.write({
            'is_processed_bridge': False,
            'bridge_project_id': False
        })
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def action_sync_from_properties(self):
        """ Pull values from Knowledge Properties into the manual fields. """
        for article in self:
            props = article.article_properties or {}
            definitions = article.article_properties_definition or []
            
            curr = article
            while not definitions and curr.parent_id:
                curr = curr.parent_id
                definitions = curr.article_properties_definition or []

            mapped = {}
            for d in definitions:
                if not isinstance(d, dict): continue
                lbl = "".join(d.get('string', '').split()).lower()
                key = d.get('name')
                val = props.get(key)
                mapped[lbl] = val

            vals = {}
            if mapped.get('projectname'): vals['bridge_project_name'] = mapped['projectname']
            
            article.write(vals)

    def action_send_daily_todo_digest(self):
        """ Sends a daily digest grouped by project to all employees with pending tasks """
        _logger.info("Starting daily project digest for all employees")
        
        employees = self.env['hr.employee'].sudo().search([('user_id', '!=', False)])
        template = self.env.ref('the_system.email_template_daily_todo_digest', raise_if_not_found=False)
        if not template:
            _logger.warning("Daily digest template not found")
            return

        today = fields.Date.context_today(self)

        for employee in employees:
            try:
                if not employee.work_email:
                    _logger.info("Skipping employee %s - no work email", employee.name)
                    continue

                # Find all bridge-visible tasks assigned to this employee
                todo_stage = self.env.ref('the_system.bridge_stage_todo', raise_if_not_found=False)
                help_stage = self.env.ref('the_system.bridge_stage_need_help', raise_if_not_found=False)
                active_stage_ids = [s.id for s in (todo_stage + help_stage) if s]
                domain = [
                    ('is_bridge_visible', '=', True),
                    ('stage_id', 'in', active_stage_ids),
                    ('user_ids', 'in', [employee.user_id.id])
                ]
                tasks = self.env['project.task'].sudo().search(domain)

                # Group tasks by project
                project_summaries = {}
                for task in tasks:
                    proj = task.project_id
                    if not proj:
                        continue
                    if proj.id not in project_summaries:
                        project_summaries[proj.id] = {
                            'project_name': proj.name,
                            'task_count': 0,
                            'deadline': None,
                        }
                    project_summaries[proj.id]['task_count'] += 1
                    # Earliest deadline (use date_deadline, fallback to planned_date_begin)
                    task_date = task.date_deadline or task.planned_date_begin
                    if task_date:
                        task_date = task_date.date() if hasattr(task_date, 'date') else task_date
                        if project_summaries[proj.id]['deadline'] is None or task_date < project_summaries[proj.id]['deadline']:
                            project_summaries[proj.id]['deadline'] = task_date

                # Also include upcoming scheduled projects from the matrix
                scheduled_articles = self.env['knowledge.article'].sudo().search([
                    ('is_project_template_bridge', '=', True),
                    ('is_processed_bridge', '=', True),
                    ('bridge_project_id', '!=', False),
                    ('bridge_schedule_ids.employee_id.user_id', '=', employee.user_id.id),
                ])
                for article in scheduled_articles:
                    proj = article.bridge_project_id
                    if proj.id in project_summaries:
                        continue  # Already have active tasks for this project
                    # Check if employee is scheduled for any future day
                    has_schedule = any(
                        s.employee_id.user_id == employee.user_id
                        for s in article.bridge_schedule_ids
                    )
                    if has_schedule:
                        project_summaries[proj.id] = {
                            'project_name': proj.name,
                            'task_count': 0,
                            'deadline': None,
                        }

                if project_summaries:
                    summaries_list = list(project_summaries.values())
                    template.with_context(project_summaries=summaries_list).send_mail(employee.id, force_send=True)
                    _logger.info("Daily digest sent to %s (%s) - %d projects",
                                 employee.name, employee.work_email, len(summaries_list))
                else:
                    _logger.debug("No pending tasks or scheduled projects for employee %s", employee.name)

            except Exception as e:
                _logger.error("Failed to send daily digest to employee %s: %s", employee.name, str(e))

        _logger.info("Daily project digest completed")

    def action_send_test_digest(self):
        """ Manual trigger for testing the digest for a user in the schedule. """
        self.ensure_one()
        if not self.bridge_schedule_ids:
            return

        employee = self.bridge_schedule_ids[0].employee_id
        template = self.env.ref('the_system.email_template_daily_todo_digest', raise_if_not_found=False)
        if not template:
            return

        try:
            todo_stage = self.env.ref('the_system.bridge_stage_todo', raise_if_not_found=False)
            help_stage = self.env.ref('the_system.bridge_stage_need_help', raise_if_not_found=False)
            active_stage_ids = [s.id for s in (todo_stage + help_stage) if s]
            domain = [
                ('is_bridge_visible', '=', True),
                ('stage_id', 'in', active_stage_ids),
                ('user_ids', 'in', [employee.user_id.id])
            ]
            tasks = self.env['project.task'].sudo().search(domain, limit=50)

            # Group tasks by project
            project_summaries = {}
            for task in tasks:
                proj = task.project_id
                if not proj:
                    continue
                if proj.id not in project_summaries:
                    project_summaries[proj.id] = {
                        'project_name': proj.name,
                        'task_count': 0,
                        'deadline': None,
                    }
                project_summaries[proj.id]['task_count'] += 1
                task_date = task.date_deadline or task.planned_date_begin
                if task_date:
                    task_date = task_date.date() if hasattr(task_date, 'date') else task_date
                    if project_summaries[proj.id]['deadline'] is None or task_date < project_summaries[proj.id]['deadline']:
                        project_summaries[proj.id]['deadline'] = task_date

            # Include this article's project if not already present
            if self.bridge_project_id and self.bridge_project_id.id not in project_summaries:
                project_summaries[self.bridge_project_id.id] = {
                    'project_name': self.bridge_project_id.name,
                    'task_count': 0,
                    'deadline': None,
                }

            if project_summaries:
                summaries_list = list(project_summaries.values())
                template.with_context(project_summaries=summaries_list).send_mail(employee.id, force_send=True)
                _logger.info("Test digest sent to %s", employee.name)
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('Test Email Sent'),
                        'message': _('Digest sent to %s (%d projects)') % (employee.name, len(summaries_list)),
                        'type': 'success',
                    }
                }
            else:
                return {
                    'type': 'ir.actions.client',
                    'tag': 'display_notification',
                    'params': {
                        'title': _('No Tasks Found'),
                        'message': _('No pending tasks found for %s') % employee.name,
                        'type': 'warning',
                    }
                }

        except Exception as e:
            _logger.error("Failed to send test digest to employee %s: %s", employee.name, str(e))
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Error'),
                    'message': _('Failed to send test email: %s') % str(e),
                    'type': 'danger',
                }
            }

    def _get_li_text(self, li_element):
        el = copy.deepcopy(li_element)
        for sub in el.xpath('.//ul | .//ol'):
            sub.drop_tree()
        return " ".join(el.text_content().split()).strip()


    def action_create_project_from_template(self):
        articles = self if self else self.sudo().search([
            ('is_project_template_bridge', '=', True),
            ('is_processed_bridge', '=', False)
        ])

        for article in articles:
            if not article.is_project_template_bridge:
                continue

            p_name = article.bridge_project_name or article.name
            
            # Create Master Project
            project = self.env['project.project'].sudo().create({
                'name': str(p_name),
                'user_id': self.env.user.id,
                'privacy_visibility': 'portal',
            })

            # Share with all scheduled employees
            partners_to_share = []
            for sched in article.bridge_schedule_ids:
                emp = sched.employee_id
                partner = emp.work_contact_id or (emp.user_id and emp.user_id.partner_id)
                if partner and partner not in partners_to_share:
                    partners_to_share.append(partner)
            
            # Grant access to the SOP article for all scheduled employees
            # Ensure current user has write access first (required by Knowledge)
            if partners_to_share:
                writer_partner = self.env.user.partner_id
                try:
                    article.sudo()._add_members(writer_partner, 'write')
                except Exception:
                    pass  # May already be a member

                # Add scheduled employees as read-only, excluding the writer
                read_partners = [p for p in partners_to_share if p.id != writer_partner.id]
                if read_partners:
                    read_partner_records = self.env['res.partner'].browse([p.id for p in read_partners])
                    try:
                        article.sudo()._add_members(read_partner_records, 'read')
                    except Exception as e:
                        _logger.warning("Failed to add read members to article '%s': %s", article.name, str(e))

            # Add partners as project collaborators (Odoo 18 sharing)
            for partner in partners_to_share:
                self.env['project.collaborator'].sudo().create({
                    'project_id': project.id,
                    'partner_id': partner.id,
                })

            # Create/Find Stages by XML ID
            stage_refs = [
                ('the_system.bridge_stage_todo', 10),
                ('the_system.bridge_stage_need_help', 20),
                ('the_system.bridge_stage_done', 30),
            ]
            stages = []
            for xml_id, seq in stage_refs:
                stage = self.env.ref(xml_id, raise_if_not_found=False)
                if not stage:
                    stage = self.env['project.task.type'].sudo().create({
                        'name': xml_id.split('.')[-1].replace('bridge_stage_', '').replace('_', ' ').title(),
                        'sequence': seq,
                    })
                stages.append(stage)
            
            project.write({'type_ids': [(6, 0, [s.id for s in stages])]})

            article.sudo().write({
                'is_processed_bridge': True,
                'bridge_project_id': project.id,
            })

            # Immediately run engine for today to bootstrap tasks
            article._cron_generate_daily_tasks(force_today=True)

        return {'type': 'ir.actions.client', 'tag': 'reload'}

    @api.model
    def _cron_generate_daily_tasks(self, force_today=False):
        """
        The Daily Engine. Scans matrices and generates tasks.
        
        Logic:
        - Weekly: Creates tasks on matching weekdays (deadline = today)
        - Monthly: Creates on scheduled day, deadline = next month
        - Quarterly: Creates on scheduled day in Jan/Apr/Jul/Oct, deadline = next quarter
        - Yearly: Creates on scheduled day in January, deadline = next year
        - Button press (force_today): Creates first task immediately for all schedules
        """
        _logger.info("Bridge Engine: Starting daily task generation.")
        today = fields.Date.context_today(self)
        
        weekday = today.weekday()  # 0 = Mon, 6 = Sun
        day = today.day
        month = today.month

        # Map weekday to schedule field
        wd_fields = {0: 'mon', 1: 'tue', 2: 'wed', 3: 'thu', 4: 'fri', 5: 'sat', 6: 'sun'}
        today_field = wd_fields.get(weekday)

        articles = self if force_today else self.sudo().search([
            ('is_project_template_bridge', '=', True),
            ('is_processed_bridge', '=', True),
            ('bridge_project_id', '!=', False)
        ])

        for article in articles:
            if not article.body or not article.bridge_schedule_ids:
                continue

            # Collect all users who need tasks today, grouped by deadline
            users_by_deadline = {}  # deadline_dt -> list of user_ids
            
            for sched in article.bridge_schedule_ids:
                if not sched.employee_id.user_id:
                    continue

                sched_day = sched.day or 1
                sched_type = sched.schedule_type
                matches = False
                deadline_dt = None

                if force_today:
                    # Button press: create first task for all schedules
                    matches = True
                    if sched_type == 'weekly':
                        deadline_dt = datetime.combine(today, datetime.min.time())
                    else:
                        deadline_dt = self._calculate_next_deadline(today, sched_day, sched_type)
                else:
                    # Daily cron: check if schedule matches today
                    if sched_type == 'weekly' and getattr(sched, today_field):
                        matches = True
                        deadline_dt = datetime.combine(today, datetime.min.time())
                    elif sched_type == 'monthly' and day == sched_day:
                        matches = True
                        deadline_dt = self._calculate_next_deadline(today, sched_day, 'monthly')
                    elif sched_type == 'quarterly' and day == sched_day and month in [1, 4, 7, 10]:
                        matches = True
                        deadline_dt = self._calculate_next_deadline(today, sched_day, 'quarterly')
                    elif sched_type == 'yearly' and day == sched_day and month == 1:
                        matches = True
                        deadline_dt = self._calculate_next_deadline(today, sched_day, 'yearly')

                if matches and deadline_dt:
                    # Collect all users for this deadline (original behavior)
                    if deadline_dt not in users_by_deadline:
                        users_by_deadline[deadline_dt] = []
                    u_id = sched.employee_id.user_id.id
                    if u_id not in users_by_deadline[deadline_dt]:
                        users_by_deadline[deadline_dt].append(u_id)

            # Create tasks once for all users
            project = article.bridge_project_id
            todo_stage = self.env.ref('the_system.bridge_stage_todo', raise_if_not_found=False)
            sop_content = article.body or ''

            for deadline_dt, target_user_ids in users_by_deadline.items():
                # Check if tasks already exist for this deadline to prevent duplication
                existing_tasks = self.env['project.task'].sudo().search([
                    ('project_id', '=', project.id),
                    ('date_deadline', '=', deadline_dt),
                ], limit=1)
                if existing_tasks:
                    _logger.info("Tasks already exist for deadline %s, skipping", deadline_dt)
                    continue

                root = lxml.html.fromstring(article.body)
                last_root_task = None  # Track the last root task for sub-tasks
                task_sequence = 10

                for li in root.xpath('//li'):
                    is_nested_container = 'oe-nested' in li.attrib.get('class', '')
                    
                    title = self._get_li_text(li)
                    if not title:
                        continue

                    t_vals = {
                        'name': title,
                        'project_id': project.id,
                        'description': '',
                        'bridge_sop_content': sop_content,
                        'sequence': task_sequence,
                        'stage_id': todo_stage.id if todo_stage else False,
                        'user_ids': [(6, 0, target_user_ids)],
                        'planned_date_begin': deadline_dt,
                        'date_deadline': deadline_dt,
                    }
                    task_sequence += 10

                    # If this li is inside an oe-nested container, it's a sub-task
                    parent_li = li.getparent()
                    is_subtask = False
                    while parent_li is not None:
                        if 'oe-nested' in parent_li.attrib.get('class', ''):
                            is_subtask = True
                            break
                        parent_li = parent_li.getparent()
                    
                    if is_subtask and last_root_task:
                        t_vals['parent_id'] = last_root_task.id

                    try:
                        new_task = self.env['project.task'].sudo().with_context(mail_notrack=True).create(t_vals)
                        chatter_msg = Markup(_('Task generated from SOP: %s')) % article.name
                        new_task.message_post(
                            body=chatter_msg,
                            message_type='comment',
                            subtype_xmlid='mail.mt_note'
                        )
                        # Track root tasks (not sub-tasks)
                        if not is_subtask:
                            last_root_task = new_task
                    except Exception as e:
                        _logger.error("Bridge Engine Task Creation Error for '%s': %s", title, str(e))
                        if 'parent_id' in t_vals:
                            del t_vals['parent_id']
                            try:
                                new_task = self.env['project.task'].sudo().with_context(mail_notrack=True).create(t_vals)
                                if not is_subtask:
                                    last_root_task = new_task
                            except Exception as fallback_e:
                                _logger.error("Bridge Engine Fallback Task Creation Error for '%s': %s", title, str(fallback_e))

        _logger.info("Bridge Engine: Finished daily task generation.")

    def _calculate_next_deadline(self, today, sched_day, schedule_type):
        """Calculate the next deadline for periodic schedules."""
        deadline_year = today.year
        deadline_month = today.month

        # If today is on or past the scheduled day, move to next month
        if today.day >= sched_day:
            deadline_month += 1
            if deadline_month > 12:
                deadline_month = 1
                deadline_year += 1

        if schedule_type == 'monthly':
            # Next month's scheduled day
            pass
        elif schedule_type == 'quarterly':
            # Next quarter month (Jan, Apr, Jul, Oct)
            valid_quarter_months = [1, 4, 7, 10]
            while deadline_month not in valid_quarter_months:
                deadline_month += 1
                if deadline_month > 12:
                    deadline_month = 1
                    deadline_year += 1
        elif schedule_type == 'yearly':
            # Next January
            deadline_month = 1
            if today.month > 1 or (today.month == 1 and today.day >= sched_day):
                deadline_year += 1

        try:
            deadline_date = date(deadline_year, deadline_month, sched_day)
        except ValueError:
            max_day = calendar.monthrange(deadline_year, deadline_month)[1]
            deadline_date = date(deadline_year, deadline_month, min(sched_day, max_day))

        return datetime.combine(deadline_date, datetime.min.time())
