import base64
import mimetypes
from odoo import http, _
from odoo.http import request
from odoo.osv import expression
from markupsafe import Markup
import logging

_logger = logging.getLogger(__name__)

from odoo.addons.project.controllers.portal import ProjectCustomerPortal

class KnowledgeProjectPortal(ProjectCustomerPortal):

    def _get_portal_tasks_domain(self):
        """ Force the portal task domain to only show tasks assigned to the current user that are bridge-visible. """
        return [
            ('user_ids', 'in', [request.env.user.id]),
            ('is_bridge_visible', '=', True)
        ]

    def _get_my_tasks_domain(self):
        """ Older Odoo compatibility or fallback. """
        return self._get_portal_tasks_domain()

    def _task_get_searchbar_filters(self, *args, **kwargs):
        """ Ensure all filters (All, Open, etc.) incorporate our strict user-based domain. """
        filters = super()._task_get_searchbar_filters(*args, **kwargs)
        if not filters:
             return filters
             
        user_domain = [('user_ids', 'in', [request.env.user.id])]
        for key in filters:
            if 'domain' in filters[key]:
                filters[key]['domain'] = expression.AND([filters[key]['domain'], user_domain])
        return filters

    def _task_get_searchbar_sortings(self, *args, **kwargs):
        """ Add 'Sequence' as a sorting option for the portal. Supports Enterprise arguments. """
        sortings = super()._task_get_searchbar_sortings(*args, **kwargs)
        # Odoo 18 requires a 'sequence' key for UI ordering, otherwise it throws KeyError
        sortings['sequence'] = {
            'label': _('SOP Order'), 
            'order': 'sequence, id',
            'sequence': 1
        }
        return sortings

    def _prepare_home_portal_values(self, counters):
        """ Update the task count to match our restricted domain. """
        values = super()._prepare_home_portal_values(counters)
        if 'task_count' in counters:
            domain = self._get_portal_tasks_domain()
            values['task_count'] = request.env['project.task'].sudo().search_count(domain)
        return values

    @http.route(['/my/tasks', '/my/tasks/page/<int:page>'], type='http', auth="user", website=True)
    def portal_my_tasks(self, **kw):
        """ Force 'Sequence' (SOP Order) as the default sorting if none is selected. """
        if 'sortby' not in kw:
            kw['sortby'] = 'sequence'
        return super().portal_my_tasks(**kw)

    @http.route(['/my/tasks/<int:task_id>/done'], type='http', auth="user", website=True)
    def portal_task_mark_done(self, task_id, **kw):
        task = request.env['project.task'].sudo().browse(task_id)
        if task.exists():
            task.action_portal_mark_done_recursive()
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/todo'], type='http', auth="user", website=True)
    def portal_task_mark_todo(self, task_id, **kw):
        task = request.env['project.task'].sudo().browse(task_id)
        if task.exists():
            task.action_portal_mark_todo()
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/help'], type='http', auth="user", methods=['GET', 'POST'], website=True, csrf=True)
    def portal_task_need_help(self, task_id, **kw):
        task = request.env['project.task'].sudo().browse(task_id)
        if task.exists():
            reason = kw.get('reason')
            task.action_portal_need_help(reason=reason)
        return request.redirect(request.httprequest.referrer or '/my/tasks')

    @http.route(['/my/tasks/<int:task_id>/upload'], type='http', auth="user", methods=['POST'], website=True, csrf=True)
    def portal_task_upload_image(self, task_id, **kw):
        try:
            task = request.env['project.task'].sudo().browse(task_id)
            file = kw.get('attachment')
            if task.exists() and file:
                filename = file.filename
                mimetype = mimetypes.guess_type(filename)[0] or 'application/octet-stream'
                file_content = file.read()
                
                if file_content:
                    attachment = request.env['ir.attachment'].sudo().create({
                        'name': filename,
                        'raw': file_content,
                        'res_model': 'project.task',
                        'res_id': task.id,
                        'mimetype': mimetype,
                        'public': True,
                    })
                    
                    # Embed image directly into the chatter message
                    msg_body = Markup(_("Image uploaded from portal checklist.<br/><br/><img src='/web/image/%s' style='max-width: 100%%; max-height: 400px; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.1);'/>")) % attachment.id
                    
                    task.sudo().message_post(
                        body=msg_body, 
                        attachment_ids=[attachment.id],
                        message_type='comment',
                        subtype_xmlid='mail.mt_comment',
                        author_id=request.env.user.partner_id.id
                    )
                    _logger.info("Successfully uploaded image %s to task %s", filename, task.id)
                else:
                    _logger.warning("Empty file uploaded to task %s", task.id)
        except Exception as e:
            _logger.error("Error uploading image to task %s: %s", task_id, str(e))
            
        return request.redirect(request.httprequest.referrer or '/my/tasks')
