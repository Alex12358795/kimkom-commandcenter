{
    'name': 'Knowledge to Project Bridge',
    'version': '1.9',
    'depends': ['knowledge', 'project', 'hr', 'website', 'portal'],
    'data': [
        'security/ir.model.access.csv',
        'data/ir_cron.xml',
        'data/mail_template_data.xml',
        'views/knowledge_article_views.xml',
        'views/project_task_views.xml',
        'views/project_portal_templates.xml',
    ],
    'installable': True,
    'license': 'LGPL-3',
}
