## Project Context
This is an Odoo 18 Enterprise custom module.


## Odoo Conventions
- All models inherit from models.Model
- Use _name for new models, _inherit for extensions
- Views go in views/ directory as XML
- Security: ir.model.access.csv + record rules in security/
- Always add models to __init__.py imports
- Always add new data/view files to __manifest__.py

## When you are done with a code change
- Always tell me if I need to do a full Odoo docker compose down & up or I can simple upgrade the module wo restarting fully

