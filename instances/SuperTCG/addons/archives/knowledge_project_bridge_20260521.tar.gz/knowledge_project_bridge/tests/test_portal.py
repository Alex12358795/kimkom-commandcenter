from odoo.tests.common import HttpCase, tagged

@tagged('post_install', '-at_install')
class TestPortalTaskFiltering(HttpCase):

    @classmethod
    def setUpClass(cls):
        super().setUpClass()
        # Create a test project
        cls.project = cls.env['project.project'].create({
            'name': 'Test Project',
            'privacy_visibility': 'portal',
        })
        
        # Create a portal user
        cls.user_portal = cls.env['res.users'].create({
            'name': 'Portal User',
            'login': 'portal_user',
            'email': 'portal@test.com',
            'groups_id': [(6, 0, [cls.env.ref('base.group_portal').id])],
        })
        
        # Create another portal user
        cls.other_user_portal = cls.env['res.users'].create({
            'name': 'Other Portal User',
            'login': 'other_portal_user',
            'email': 'other@test.com',
            'groups_id': [(6, 0, [cls.env.ref('base.group_portal').id])],
        })

        # Create tasks
        cls.task_assigned = cls.env['project.task'].create({
            'name': 'Assigned Task',
            'project_id': cls.project.id,
            'user_ids': [(4, cls.user_portal.id)],
            'is_bridge_visible': True,
        })
        
        cls.task_unassigned = cls.env['project.task'].create({
            'name': 'Unassigned Task',
            'project_id': cls.project.id,
            'user_ids': [(4, cls.other_user_portal.id)],
            'is_bridge_visible': True,
        })

    def test_portal_my_tasks_domain(self):
        """ Test that the portal user only sees their own assigned tasks. """
        self.authenticate('portal_user', 'portal_user')
        
        # Access /my/tasks
        response = self.url_open('/my/tasks')
        self.assertEqual(response.status_code, 200)
        
        # Check if Assigned Task is in the response content
        self.assertIn('Assigned Task', response.text)
        
        # Check if Unassigned Task is NOT in the response content
        self.assertNotIn('Unassigned Task', response.text)
