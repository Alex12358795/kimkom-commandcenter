from odoo import models, fields, api, _
from datetime import datetime, timedelta
from markupsafe import Markup
import lxml.html
import logging

_logger = logging.getLogger(__name__)

class KnowledgeBridgeSchedule(models.Model):
    _name = 'knowledge.bridge.schedule'
    _description = 'Knowledge Project Bridge Schedule Line'

    article_id = fields.Many2one('knowledge.article', string='Article', required=True, ondelete='cascade')
    employee_id = fields.Many2one('hr.employee', string='Employee', domain="[('user_id', '!=', False)]", required=True)
    
    # Weekly
    mon = fields.Boolean(string='Monday')
    tue = fields.Boolean(string='Tuesday')
    wed = fields.Boolean(string='Wednesday')
    thu = fields.Boolean(string='Thursday')
    fri = fields.Boolean(string='Friday')
    sat = fields.Boolean(string='Saturday')
    sun = fields.Boolean(string='Sunday')
    
    # Periodic
    monthly = fields.Boolean(string='Monthly', help="Runs on the 1st of every month")
    quarterly = fields.Boolean(string='Quarterly', help="Runs on Jan 1, Apr 1, Jul 1, Oct 1")
    yearly = fields.Boolean(string='Yearly', help="Runs on Jan 1")


class KnowledgeArticle(models.Model):
    _inherit = 'knowledge.article'

    is_project_template_bridge = fields.Boolean(string='Is Project Template', default=False)
    is_processed_bridge = fields.Boolean(string='Processed for Project', default=False)
    bridge_project_id = fields.Many2one('project.project', string='Generated Master Project', readonly=True)

    bridge_project_name = fields.Char(string='Project Name')
    bridge_deadline_offset = fields.Integer(string='Deadline Offset (Days)', default=0)
    
    # The New Matrix
    bridge_schedule_ids = fields.One2many('knowledge.bridge.schedule', 'article_id', string='Schedules')

    def action_reset_bridge(self):
        """ Allow re-running the bridge by resetting the processed status. """
        self.write({
            'is_processed_bridge': False,
            'bridge_project_id': False
        })
        return {'type': 'ir.actions.client', 'tag': 'reload'}

    def action_sync_from_properties(self):
        """ Pull values from Knowledge Properties into the manual fields. """
        for article in self:
            props = article.article_properties or {}
            definitions = article.article_properties_definition or []
            
            curr = article
            while not definitions and curr.parent_id:
                curr = curr.parent_id
                definitions = curr.article_properties_definition or []

            mapped = {}
            for d in definitions:
                if not isinstance(d, dict): continue
                lbl = "".join(d.get('string', '').split()).lower()
                key = d.get('name')
                val = props.get(key)
                mapped[lbl] = val

            vals = {}
            if mapped.get('projectname'): vals['bridge_project_name'] = mapped['projectname']
            if mapped.get('deadlineoffset'): vals['bridge_deadline_offset'] = int(mapped['deadlineoffset'])
            
            article.write(vals)

    def action_send_daily_todo_digest(self):
        """ Sends a daily digest to all employees who have tasks in the 'To do' stage """
        employees = self.env['hr.employee'].sudo().search([('user_id', '!=', False)])
        template = self.env.ref('knowledge_project_bridge.email_template_daily_todo_digest', raise_if_not_found=False)
        if not template:
            return

        for employee in employees:
            domain = [
                ('project_id.type_ids', '!=', False),
                ('stage_id.name', 'in', ['To do', 'Need help']),
                ('user_ids', 'in', [employee.user_id.id])
            ]
            tasks = self.env['project.task'].sudo().search(domain)
            
            if tasks:
                template.with_context(tasks=tasks).send_mail(employee.id, force_send=True)

    def action_send_test_digest(self):
        """ Manual trigger for testing the digest for a user in the schedule. """
        self.ensure_one()
        if not self.bridge_schedule_ids:
            return
            
        employee = self.bridge_schedule_ids[0].employee_id
        template = self.env.ref('knowledge_project_bridge.email_template_daily_todo_digest')
        
        domain = [
            ('stage_id.name', 'in', ['To do', 'Need help']),
            ('user_ids', 'in', [employee.user_id.id])
        ]
        tasks = self.env['project.task'].sudo().search(domain, limit=10)
        
        if tasks:
            template.with_context(tasks=tasks).send_mail(employee.id, force_send=True)
            return {
                'type': 'ir.actions.client',
                'tag': 'display_notification',
                'params': {
                    'title': _('Test Email Sent'),
                    'message': _('Digest sent to %s') % employee.name,
                    'type': 'success',
                }
            }

    def _get_li_text(self, li_element):
        import copy
        el = copy.deepcopy(li_element)
        for sub in el.xpath('.//ul | .//ol'):
            sub.drop_tree()
        return " ".join(el.text_content().split()).strip()


    def action_create_project_from_template(self):
        """ 
        Creates the MASTER project and shares it with all employees in the matrix.
        It then immediately runs the Daily Engine for today.
        """
        articles = self if self else self.sudo().search([
            ('is_project_template_bridge', '=', True),
            ('is_processed_bridge', '=', False)
        ])

        for article in articles:
            if not article.is_project_template_bridge:
                continue
                
            try:
                p_name = article.bridge_project_name or article.name
                
                # Create Master Project
                project = self.env['project.project'].sudo().create({
                    'name': str(p_name),
                    'user_id': self.env.user.id,
                })

                # Share with all scheduled employees
                partners_to_share = []
                for sched in article.bridge_schedule_ids:
                    emp = sched.employee_id
                    partner = emp.work_contact_id or (emp.user_id and emp.user_id.partner_id)
                    if partner and partner not in partners_to_share:
                        partners_to_share.append(partner)
                
                # Ensure they have access to the SOP itself
                if partners_to_share:
                    article.sudo().message_subscribe(partner_ids=[p.id for p in partners_to_share])

                if partners_to_share:
                    collab_vals = [(0, 0, {'partner_id': p.id, 'access_mode': 'edit'}) for p in partners_to_share]
                    share_wizard = self.env['project.share.wizard'].sudo().create({
                        'res_model': 'project.project',
                        'res_id': project.id,
                        'partner_ids': [(6, 0, [p.id for p in partners_to_share])],
                        'collaborator_ids': collab_vals
                    })
                    share_wizard.action_send_mail()

                # Create/Find Stages
                stage_names = [('To do', 10), ('Need help', 20), ('Done', 30)]
                stages = []
                for name, seq in stage_names:
                    stage = self.env['project.task.type'].sudo().search([('name', '=', name)], limit=1)
                    if not stage:
                        stage = self.env['project.task.type'].sudo().create({
                            'name': name,
                            'sequence': seq,
                            'fold': False
                        })
                    stages.append(stage)
                
                project.write({'type_ids': [(6, 0, [s.id for s in stages])]})

                article.sudo().write({
                    'is_processed_bridge': True,
                    'bridge_project_id': project.id,
                })

                # Immediately run engine for today to bootstrap tasks
                article._cron_generate_daily_tasks(force_today=True)

            except Exception as e:
                _logger.error("SOP Bridge Error: %s", str(e))

        return {'type': 'ir.actions.client', 'tag': 'reload'}

    @api.model
    def _cron_generate_daily_tasks(self, force_today=False):
        """
        The Daily Engine. Scans matrices and generates tasks for today.
        """
        _logger.info("Bridge Engine: Starting daily task generation.")
        today = fields.Date.context_today(self)
        
        weekday = today.weekday() # 0 = Mon, 6 = Sun
        day = today.day
        month = today.month

        # Determine which periodic triggers match today
        is_monthly = (day == 1)
        is_quarterly = (day == 1 and month in [1, 4, 7, 10])
        is_yearly = (day == 1 and month == 1)

        # Map weekday to schedule field
        wd_fields = {0: 'mon', 1: 'tue', 2: 'wed', 3: 'thu', 4: 'fri', 5: 'sat', 6: 'sun'}
        today_field = wd_fields.get(weekday)

        articles = self if force_today else self.sudo().search([
            ('is_project_template_bridge', '=', True),
            ('is_processed_bridge', '=', True),
            ('bridge_project_id', '!=', False)
        ])

        for article in articles:
            if not article.body or not article.bridge_schedule_ids:
                continue

            # Find users scheduled for today
            target_user_ids = []
            for sched in article.bridge_schedule_ids:
                matches_today = (
                    getattr(sched, today_field) or 
                    (is_monthly and sched.monthly) or 
                    (is_quarterly and sched.quarterly) or 
                    (is_yearly and sched.yearly)
                )
                if matches_today and sched.employee_id.user_id:
                    u_id = sched.employee_id.user_id.id
                    if u_id not in target_user_ids:
                        target_user_ids.append(u_id)

            if not target_user_ids:
                continue

            project = article.bridge_project_id
            todo_stage = self.env['project.task.type'].sudo().search([('name', '=', 'To do')], limit=1)
            deadline = today + timedelta(days=article.bridge_deadline_offset) if article.bridge_deadline_offset else False
            
            # Prepare the SOP Link HTML for description
            base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
            # Odoo 18 internal article URL pattern
            sop_url = f"{base_url}/odoo/knowledge/{article.id}"
            sop_link_html = f'<div class="alert alert-info" style="border-left: 5px solid #71639e;"><strong>Source SOP:</strong> <a href="{sop_url}" target="_blank">Click here to view full instructions</a></div><hr/>'

            # Parse template body
            root = lxml.html.fromstring(article.body)
            
            # Generate ONE shared checklist for all targeted users
            # Master tasks dictionary to handle nesting
            level_parents = {}
            task_sequence = 10 # Start sequence for ordering
            
            for li in root.xpath('//li'):
                if 'oe-nested' in li.attrib.get('class', ''):
                    continue

                depth = len(li.xpath('./ancestor::li'))
                title = self._get_li_text(li)
                if not title: continue

                t_vals = {
                    'name': title,
                    'project_id': project.id,
                    'description': sop_link_html,
                    'sequence': task_sequence,
                    'stage_id': todo_stage.id if todo_stage else False,
                    'user_ids': [(6, 0, target_user_ids)], 
                    'planned_date_begin': datetime.combine(today, datetime.min.time()),
                }
                task_sequence += 10 # Increment for next task
                
                if deadline:
                    t_vals['date_deadline'] = datetime.combine(deadline, datetime.min.time())

                if depth > 0 and (depth - 1) in level_parents:
                    t_vals['parent_id'] = level_parents[depth - 1].id

                try:
                    new_task = self.env['project.task'].sudo().create(t_vals)
                    # Also post to chatter using Markup for Odoo 18 HTML rendering
                    chatter_msg = Markup(_('Task generated from SOP: <a href="%s" target="_blank">%s</a>')) % (sop_url, article.name)
                    new_task.message_post(
                        body=chatter_msg,
                        message_type='comment',
                        subtype_xmlid='mail.mt_note'
                    )
                    level_parents[depth] = new_task
                except Exception as e:
                    _logger.error("Bridge Engine Task Creation Error for '%s': %s", title, str(e))
                    # If subtask fails, try without parent_id as a fallback
                    if 'parent_id' in t_vals:
                        del t_vals['parent_id']
                        try:
                            new_task = self.env['project.task'].sudo().create(t_vals)
                            level_parents[depth] = new_task
                        except Exception as fallback_e:
                            _logger.error("Bridge Engine Fallback Task Creation Error for '%s': %s", title, str(fallback_e))
                    
        _logger.info("Bridge Engine: Finished daily task generation.")
